import React from 'react';


function Header() {
  return (
    <>
      <header className="ftco-section mt-2">
        <div className="container mb-2">
            <div className="row justify-content-between">
                <div className="col-md-8 order-md-last">
                    <div className="row">
                        <div className="col-md-6 text-center">
                            <a className="navbar-brand" href="index.php">Crypto <span>Presale</span></a>
                        </div>
                        <div className="col-md-6 dHeadermd-flex justify-content-end mb-md-0 mb-3">
                            <form action="#" className="searchform order-lg-last">
                                <div className="form-group d-flex">
                                    <input type="text" className="form-control pl-3" placeholder="Search Coins"/>
                                    <button type="submit" placeholder="" className="form-control search"><span className="fa fa-search"></span></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div className="col-md-4 d-flex">
                    <div className="social-media">
                        <p className="mb-0 d-flex">
                            <a href="#" className="d-flex align-items-center justify-content-center"><i className="fa-brands fa-facebook-f"></i></a>
                            <a href="#" className="d-flex align-items-center justify-content-center"><i className="fa-brands fa-x-twitter"></i></a>
                            <a href="#" className="d-flex align-items-center justify-content-center"><i className="fa-brands fa-instagram"></i></a>
                            <a href="#" className="d-flex align-items-center justify-content-center"><i className="fa-brands fa-linkedin-in"></i></a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <nav className="navbar navbar-expand-lg bg-gradient">
            <div className="container">
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="ftco-nav">
                    <ul className="navbar-nav ">
                        <li className="nav-item">
                            <a className="nav-link " aria-current="page" href="/">Home</a>
                        </li>
                        <li className="nav-item"><a className="nav-link" href="listings">New listings</a></li>
                        <li className="nav-item"><a className="nav-link" href="submit_coin">Submit Coin</a></li>
                        <li className="nav-item"><a className="nav-link" href="update_request">Update Request</a></li>
                        <li className="nav-item"><a className="nav-link" href="advertise">Advertise</a></li>
                        <li className="nav-item"><a className="nav-link" href="guestpost">Guest Post</a></li>
                        <li className="nav-item"><a className="nav-link" href="blog">Blog</a></li>
                        <li className="nav-item"><a className="nav-link" href="contactus">Contact Us</a></li>
                      
                        {/* <!-- <li className="nav-item dropdown d-none">
                            <a className="nav-link dropdown-toggle" href="#" id="dropdown04" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Pages
                            </a>
                            <ul className="dropdown-menu" aria-labelledby="dropdown04">
                                <li><a className="dropdown-item" href="#">Page 1</a></li>
                                <li><a className="dropdown-item" href="#">Page 2</a></li>
                                <li><a className="dropdown-item" href="#">Page 3</a></li>
                                <li><a className="dropdown-item" href="#">Page 4</a></li>
                            </ul>
                        </li> --> */}
                    </ul>
                </div>
                <a href="auth/login" className="btn-main primary-btn me-2" ><span>Sign In</span></a>
                <a href="auth/signup" className="btn-main primary-btn"><span>Sign Up</span></a>
                {/* <!-- <a href="login.php" className="btn-main primary-btn me-2" data-bs-toggle="modal" data-bs-target="#signin"><span>Sign In</span></a>
                <a href="signup.php" className="btn-main primary-btn" data-bs-toggle="modal" data-bs-target="#signup"><span>Sign Up</span></a> --> */}
            </div>
        </nav>
        {/* <!-- END nav --> */}
    </header>
    </>
  ) 
}

export default Header
