'use client'
import React from 'react'

function HomePage() {
  return (
   <>
    {/* <!-- first section --> */}
    <section className="coin_bg">
        <div className="container">
            <div className="row">
                <div className="col-xl-12">
                    <div className="section-title">
                        <h2 className="h4"> Boost Your Business to New Heights</h2>
                    </div>
                </div>
                <div className="owl-slider">
                    <div id="coinslider" className="owl-carousel">
                        <div className="item">
                            <div className="cat_button">
                                <a href="" title="Bitcoin">
                                    <div className="bg_Cat"><img src="../images/altcoin.webp" loading="lazy" width="40" height="40" alt="Bitcoin Icon" /></div>
                                    Luai
                                </a>
                            </div>
                        </div>
                        <div className="item">
                            <div className="cat_button">
                                <a href="" title="Bitcoin">
                                    <div className="bg_Cat"><img src="../images/altcoin.webp" loading="lazy" width="40" height="40" alt="Bitcoin Icon" /></div>
                                    Rise
                                </a>
                            </div>
                        </div>
                        <div className="item">
                            <div className="cat_button">
                                <a href="" title="Bitcoin">
                                    <div className="bg_Cat"><img src="../images/altcoin.webp" loading="lazy" width="40" height="40" alt="Bitcoin Icon" /></div>
                                    Joge
                                </a>
                            </div>
                        </div>
                        <div className="item">
                            <div className="cat_button">
                                <a href="" title="Bitcoin">
                                    <div className="bg_Cat"><img src="../images/altcoin.webp" loading="lazy" width="40" height="40" alt="Bitcoin Icon" /></div>
                                    Rent
                                </a>
                            </div>
                        </div>
                        <div className="item">
                            <div className="cat_button">
                                <a href="" title="Bitcoin">
                                    <div className="bg_Cat"><img src="../images/altcoin.webp" loading="lazy" width="40" height="40" alt="Bitcoin Icon" /></div>
                                    TLD
                                </a>
                            </div>
                        </div>
                        <div className="item">
                            <div className="cat_button">
                                <a href="" title="Bitcoin">
                                    <div className="bg_Cat"><img src="../images/altcoin.webp" loading="lazy" width="40" height="40" alt="Bitcoin Icon" /></div>
                                    Solx
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* <!-- end --> */}
    {/* <!-- second section --> */}
    <section className="presalenew my-3">
        <div className="container">
            <div className="row">
                <div className="col-xl-4">
                    <div className="full_presaletable">
                        <div className="main_flex topheader">
                            <h5 className="mb-0 fw-bold">Top 3 Presale News</h5>
                            <a href="" className="btn btn-link text-dark">Show All</a>
                        </div>
                        <div className="block_Table p-2">
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">1</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">2</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">3</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">4</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">5</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-xl-4">
                    <div className="full_presaletable">
                        <div className="main_flex topheader">
                            <h5 className="mb-0 fw-bold">Highlighted</h5>
                            <a href="" className="btn btn-link text-dark">Your Coin Here</a>
                        </div>
                        <div className="block_Table p-2">
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">1</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">2</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">3</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">4</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">5</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-xl-4">
                    <div className="full_presaletable">
                        <div className="main_flex topheader">
                            <h5 className="mb-0 fw-bold">Trending Presales</h5>
                            <a href="" className="btn btn-link text-dark">View More</a>
                        </div>
                        <div className="block_Table p-2">
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">1</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">2</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">3</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">4</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                            <div className="main_flex mb-2">
                                <h6><span className="border_circle">5</span> goodcrypto</h6>
                                <button className="btn-main primary-btn small px-4 btn-second_main">See All</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* <!-- end --> */}
    {/* <!-- third section --> */}
    <section className="tablesection pt-4">
        <div className="container mb-4">
            <div className="row">
                <div className="col-xl-12">
                    <div className="table_block">
                        <div className="table_top main_flex">
                            <h6 className="h4 fw-semibold mb-0">Promoted</h6>
                            <a href="" className="btn btn-link text-presale">Your coin here? Contact us!</a>
                        </div>
                        <div className="table_main">
                            <div className="table-responsive">
                                <table className="table table-bg table-striped">
                                    <thead>
                                        <tr>
                                        <th>#</th>
                                        <th>Coin</th>
                                        <th>Name</th>
                                        <th>Badges</th>
                                        <th> Market Cap</th>
                                        <th> Price</th>
                                        <th> Change 24h</th>
                                        <th> Launch</th>
                                        <th> Total Boosts</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><img src="../images/altcoin.webp" width="30" height="30" /></td>
                                            <td>LCAI</td>
                                            <td><span className="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                            <td>Presale</td>
                                            <td>-</td>
                                            <td><span>Hardcap 9000</span></td>
                                            <td> In 3 months</td>
                                            <td>
                                                <div className="main_flex_Gap">
                                                    <span> In 3 months</span>
                                                    <button className="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                    <i className="fa-regular fa-star"></i>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td><img src="../images/altcoin.webp" width="30" height="30" /></td>
                                            <td>LCAI</td>
                                            <td><span className="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                            <td>Presale</td>
                                            <td>-</td>
                                            <td><span>Hardcap 9000</span></td>
                                            <td> In 3 months</td>
                                            <td>
                                                <div className="main_flex_Gap">
                                                    <span> In 3 months</span>
                                                    <button className="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                    <i className="fa-regular fa-star"></i>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td><img src="../images/altcoin.webp" width="30" height="30" /></td>
                                            <td>LCAI</td>
                                            <td><span className="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                            <td>Presale</td>
                                            <td>-</td>
                                            <td><span>Hardcap 9000</span></td>
                                            <td> In 3 months</td>
                                            <td>
                                                <div className="main_flex_Gap">
                                                    <span> In 3 months</span>
                                                    <button className="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                    <i className="fa-regular fa-star"></i>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td><img src="../images/altcoin.webp" width="30" height="30" /></td>
                                            <td>LCAI</td>
                                            <td><span className="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                            <td>Presale</td>
                                            <td>-</td>
                                            <td><span>Hardcap 9000</span></td>
                                            <td> In 3 months</td>
                                            <td>
                                                <div className="main_flex_Gap">
                                                    <span> In 3 months</span>
                                                    <button className="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                    <i className="fa-regular fa-star"></i>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <img src="../images/vector-row-bg.webp" className="centertable" />
        <div className="container">
            <div className="row">
                <div className="col-xl-12">
                    <div className="section-title">
                        <h5 className="h4 fw-semibold">Best Crypto Presales 2024</h5>
                        <p>Looking for the best and newest crypto presales and ICOs to invest in? You're in the right place at Cryptopresale.net. We list the most exciting upcoming and active crypto presales of 2024. Our presales overview gives you all the key details. Whether you're new to crypto or a seasoned investor, Cryptopresale is your go-to for the top presale opportunities.</p>
                    </div>
                    <div className="filtertable">
                        <div className="filterblock">
                            <label>Chain</label>
                            <div className="dropdown">
                                <button className=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    All Chains
                                </button>
                                <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label className="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label className="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label className="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="filterblock">
                            <label>Category</label>
                            <div className="dropdown">
                                <button className=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    All Categories
                                </button>
                                <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label className="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label className="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label className="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="filterblock">
                            <label>Platform</label>
                            <div className="dropdown">
                                <button className=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    All Platforms
                                </button>
                                <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label className="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label className="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label className="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="filterblock">
                            <label>Soft Cap</label>
                            <select className="form-control">
                                <option>All Chains</option>
                            </select>
                        </div>
                        <div className="filterblock">
                            <label>Hard Cap</label>
                            <select className="form-control">
                                <option>All Chains</option>
                            </select>
                        </div>
                        <div className="filterblock">
                            <div className="d-flex align-items-center gap-2"><label>Audit </label><label className="switch"> <input type="checkbox" />
                                    <div className="slider round"></div>
                                </label></div>
                            <div className="dropdown">
                                <button className=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    Select Companies
                                </button>
                                <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label className="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label className="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label className="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="filterblock">
                            <div className="d-flex align-items-center gap-2"><label>KYC </label><label className="switch"> <input type="checkbox" />
                                    <div className="slider round"></div>
                                </label></div>
                            <div className="dropdown">
                                <button className=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    Select Tiers
                                </button>
                                <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label className="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label className="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li className="dropdown-item">
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label className="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div className="filterblock">
                            <label className="mb-1">Listings</label>
                            <div className="radio-toolbar">
                              <input type="radio" id="radio1" name="radios" value="all" checked />
                              <label for="radio1">Show All</label>
                              <input type="radio" id="radio2" name="radios" value="false" />
                              <label for="radio2">Presale Live</label>
                              <input type="radio" id="radio3" name="radios" value="true" />
                              <label for="radio3">Presale Upcoming</label>
                              <input type="radio" id="radio4" name="radios" value="true" />
                              <label for="radio4">Fair Launch Live</label>
                              <input type="radio" id="radio5" name="radios" value="true" />
                              <label for="radio5">Fair Launch Upcoming</label>
                            </div>
                        </div>
                    </div>
                    <div className="table_main">
                        <div className="table-responsive">
                            <table className="table table-bg table-striped">
                                <thead>
                                    <tr>
                                    <th>#</th>
                                    <th>Coin</th>
                                    <th>Name</th>
                                    <th>Badges</th>
                                    <th> Market Cap</th>
                                    <th> Price</th>
                                    <th> Change 24h</th>
                                    <th> Launch</th>
                                    <th> Total Boosts</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td><img src="../images/altcoin.webp" width="30" height="30" /></td>
                                        <td>LCAI</td>
                                        <td><span className="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                        <td>Presale</td>
                                        <td>-</td>
                                        <td><span>Hardcap 9000</span></td>
                                        <td> In 3 months</td>
                                        <td>
                                            <div className="main_flex_Gap">
                                                <span> In 3 months</span>
                                                <button className="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                <i className="fa-regular fa-star"></i>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td><img src="../images/altcoin.webp" width="30" height="30" /></td>
                                        <td>LCAI</td>
                                        <td><span className="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                        <td>Presale</td>
                                        <td>-</td>
                                        <td><span>Hardcap 9000</span></td>
                                        <td> In 3 months</td>
                                        <td>
                                            <div className="main_flex_Gap">
                                                <span> In 3 months</span>
                                                <button className="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                <i className="fa-regular fa-star"></i>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td><img src="../images/altcoin.webp" width="30" height="30" /></td>
                                        <td>LCAI</td>
                                        <td><span className="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                        <td>Presale</td>
                                        <td>-</td>
                                        <td><span>Hardcap 9000</span></td>
                                        <td> In 3 months</td>
                                        <td>
                                            <div className="main_flex_Gap">
                                                <span> In 3 months</span>
                                                <button className="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                <i className="fa-regular fa-star"></i>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td><img src="../images/altcoin.webp" width="30" height="30" /></td>
                                        <td>LCAI</td>
                                        <td><span className="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                        <td>Presale</td>
                                        <td>-</td>
                                        <td><span>Hard/?#cap 9000</span></td>
                                        <td> In 3 months</td>
                                        <td>
                                            <div className="main_flex_Gap">
                                                <span> In 3 months</span>
                                                <button className="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                <i className="fa-regular fa-star"></i>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* <!-- faq section --> */}
    <section className="py-4">
        <div className="container">
            <div className="row">
                <div className="col-xl-8">
                    <div className="section-title text-center">
                        <h5 className="fw-bold h4">Frequently Asked Questions</h5>
                        <p>Have questions? We have answers!</p>
                    </div>
                    <div className="accordion-container">
                        <div className="accordion-item">
                            <button className="accordion-header">
                                What are crypto presales? <span className="icon">+</span>
                            </button>
                            <div className="accordion-content">
                                <p>Crypto presales, also known as Initial Coin Offerings (ICOs), token presales, or early-stage token sales, offer investors a chance to purchase a cryptocurrency's tokens before a public launch. These early investment opportunities, often available at a lower price, aim to fund project development and marketing efforts. They are pivotal for both project teams, seeking capital to bring their visions to life, and for investors, looking for potential high returns from the ground floor of innovative blockchain projects.</p>
                            </div>
                        </div>
                        <div className="accordion-item">
                            <button className="accordion-header">
                                How do crypto presales work? <span className="icon">+</span>
                            </button>
                            <div className="accordion-content">
                                <p>Answer to question 2...</p>
                            </div>
                        </div>
                        <div className="accordion-item">altcoin.webp
                            <button className="accordion-header">
                                Are crypto presales worth it?<span className="icon">+</span>
                            </button>
                            <div className="accordion-content">
                                <p>Answer to question 3...</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-xl-4">
                    <div className="contact_block text-center"> 
                        <div className="iconbox mb-4">
                            <img src="../images/contact-us.png" width="75" height="75" />
                        </div>
                        <div className="contact_faq">
                            <h5>You have different questions?</h5>
                            <p>Our team will answer all your questions. we ensure a quick response.</p>
                            <a href="" className="btn-main primary-btn shadow">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* <!--  --> */}
    <section className="listingblock">
        <div className="container">
            <div className="row justify-content-center">
                <div className="col-xl-5">
                    <div className="listing_box box_left">
                        <div className="contentview">
                            <h5 className="h3">Your Favorite Coin Missing?</h5>
                            <p>Can't find your coin? List your favorite coin now!
                                Get your community to vote for your coin and gain exposure.</p>
                            <a href="" className="btn-main primary-btn shadow">Submit Coin</a>
                        </div>
                    </div>
                </div>
                <div className="col-xl-5">
                    <div className="listing_box ">
                        <div className="contentview">
                            <h5 className="h3">View New Listings</h5><br/>
                            <p>Click the button below to view the New Listings!images
                                These coins were just submitted.</p><br/>
                            <a href="" className="btn-main primary-btn shadow">View New Listings</a>
                        </div>
                    </div>
                </div>
                <div className="col-xl-12 mt-4">
                    <h5 className="h3 text-white mb-3">Find the best new cryptocurrency projects</h5>
                    <p className="text-white">Did ever you wonder where people find the best new cryptocurrency projects, coins and tokens like Doge and Shiba Inu? They use websites like crypto presale. Cryptocurrency projects are listed here before CoinMarketCap, CoinGecko and major exchanges. Find the best crypto moonshots on our website.
                        However: before investing always do your own research (DYOR)! Listing on crypto presale does NOT mean we endorse the project, they could be scams. Be careful with your investments.</p>
                    <h5 className="h3 text-white">How does Crypto Presale work?</h5>
                    <p className="text-white">Did ever you wonder where people find the best new cryptocurrency projects, coins and tokens like Doge and Shiba Inu? They use websites like crypto presale. Cryptocurrency projects are listed here before CoinMarketCap, CoinGecko and major exchanges. Find the best crypto moonshots on our website.
                        However: before investing always do your own research (DYOR)! Listing on crypto presale does NOT mean we endorse the project, they could be scams. Be careful with your investments.</p>
                </div>
            </div>
        </div>
    </section>
   </>
  )
}

export default HomePage
