import React from 'react'

function Listings() {
  return (
    <>
      <section class="brdcrumb">
    <div class="container">
        <ul class="mb-0">
            <li><a href="index.php" title="Home">Home</a></li>
            <li>Listings</li>
        </ul>
    </div>
</section>
    {/* <!-- third section --> */}
    <section class="tablesection pt-4">
        <div class="container mb-4">
            <div class="row">
                <div class="col-xl-12">
                    <div class="table_block">
                        <div class="table_top main_flex">
                            <h6 class="h4 fw-semibold mb-0">Promoted</h6>
                            <a href="" class="btn btn-link text-presale">Your coin here? Contact us!</a>
                        </div>
                        <div class="table_main">
                            <div class="table-responsive">
                                <table class="table table-bg table-striped">
                                    <thead>
                                        <tr>
                                        <th>#</th>
                                        <th>Coin</th>
                                        <th>Name</th>
                                        <th>Badges</th>
                                        <th> Market Cap</th>
                                        <th> Price</th>
                                        <th> Change 24h</th>
                                        <th> Launch</th>
                                        <th> Total Boosts</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td><img src="images/altcoin.webp" width="30" height="30" /></td>
                                            <td>LCAI</td>
                                            <td><span class="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                            <td>Presale</td>
                                            <td>-</td>
                                            <td><span>Hardcap 9000</span></td>
                                            <td> In 3 months</td>
                                            <td>
                                                <div class="main_flex_Gap">
                                                    <span> In 3 months</span>
                                                    <button class="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                    <i class="fa-regular fa-star"></i>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td><img src="images/altcoin.webp" width="30" height="30"/></td>
                                            <td>LCAI</td>
                                            <td><span class="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                            <td>Presale</td>
                                            <td>-</td>
                                            <td><span>Hardcap 9000</span></td>
                                            <td> In 3 months</td>
                                            <td>
                                                <div class="main_flex_Gap">
                                                    <span> In 3 months</span>
                                                    <button class="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                    <i class="fa-regular fa-star"></i>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td><img src="images/altcoin.webp" width="30" height="30" /></td>
                                            <td>LCAI</td>
                                            <td><span class="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                            <td>Presale</td>
                                            <td>-</td>
                                            <td><span>Hardcap 9000</span></td>
                                            <td> In 3 months</td>
                                            <td>
                                                <div class="main_flex_Gap">
                                                    <span> In 3 months</span>
                                                    <button class="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                    <i class="fa-regular fa-star"></i>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td><img src="images/altcoin.webp" width="30" height="30" /></td>
                                            <td>LCAI</td>
                                            <td><span class="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                            <td>Presale</td>
                                            <td>-</td>
                                            <td><span>Hardcap 9000</span></td>
                                            <td> In 3 months</td>
                                            <td>
                                                <div class="main_flex_Gap">
                                                    <span> In 3 months</span>
                                                    <button class="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                    <i class="fa-regular fa-star"></i>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <img src="images/vector-row-bg.webp" class="centertable" />
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="section-title">
                        <h5 class="h4 fw-semibold">Best Crypto Presales 2024</h5>
                        <p>Looking for the best and newest crypto presales and ICOs to invest in? You're in the right place at Cryptopresale.net. We list the most exciting upcoming and active crypto presales of 2024. Our presales overview gives you all the key details. Whether you're new to crypto or a seasoned investor, Cryptopresale is your go-to for the top presale opportunities.</p>
                    </div>
                    <div class="filtertable">
                        <div class="filterblock">
                            <label>Chain</label>
                            <div class="dropdown">
                                <button class=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    All Chains
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label class="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label class="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label class="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="filterblock">
                            <label>Category</label>
                            <div class="dropdown">
                                <button class=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    All Categories
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label class="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label class="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label class="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="filterblock">
                            <label>Platform</label>
                            <div class="dropdown">
                                <button class=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    All Platforms
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label class="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label class="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label class="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="filterblock">
                            <label>Soft Cap</label>
                            <select class="form-control">
                                <option>All Chains</option>
                            </select>
                        </div>
                        <div class="filterblock">
                            <label>Hard Cap</label>
                            <select class="form-control">
                                <option>All Chains</option>
                            </select>
                        </div>
                        <div class="filterblock">
                            <div class="d-flex align-items-center gap-2"><label>Audit </label><label class="switch"> <input type="checkbox" />
                                    <div class="slider round"></div>
                                </label></div>
                            <div class="dropdown">
                                <button class=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    Select Companies
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label class="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label class="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label class="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="filterblock">
                            <div class="d-flex align-items-center gap-2"><label>KYC </label><label class="switch"> <input type="checkbox" />
                                    <div class="slider round"></div>
                                </label></div>
                            <div class="dropdown">
                                <button class=" dropdown-toggle form-control text-start" type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown" aria-expanded="false">
                                    Select Tiers
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme1" />
                                            <label class="form-check-label" for="Checkme1">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme2" />
                                            <label class="form-check-label" for="Checkme2">Check me</label>
                                        </div>
                                    </li>
                                    <li class="dropdown-item">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="Checkme3" />
                                            <label class="form-check-label" for="Checkme3">Check me</label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="filterblock">
                            <label>Listings</label>
                            <select class="form-control">
                                <option>All Chains</option>
                            </select>
                        </div>
                    </div>
                    <div class="table_main">
                        <div class="table-responsive">
                            <table class="table table-bg table-striped">
                                <thead>
                                    <tr>
                                    <th>#</th>
                                    <th>Coin</th>
                                    <th>Name</th>
                                    <th>Badges</th>
                                    <th> Market Cap</th>
                                    <th> Price</th>
                                    <th> Change 24h</th>
                                    <th> Launch</th>
                                    <th> Total Boosts</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td><img src="images/altcoin.webp" width="30" height="30" /></td>
                                        <td>LCAI</td>
                                        <td><span class="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                        <td>Presale</td>
                                        <td>-</td>
                                        <td><span>Hardcap 9000</span></td>
                                        <td> In 3 months</td>
                                        <td>
                                            <div class="main_flex_Gap">
                                                <span> In 3 months</span>
                                                <button class="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                <i class="fa-regular fa-star"></i>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td><img src="images/altcoin.webp" width="30" height="30" /></td>
                                        <td>LCAI</td>
                                        <td><span class="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                        <td>Presale</td>
                                        <td>-</td>
                                        <td><span>Hardcap 9000</span></td>
                                        <td> In 3 months</td>
                                        <td>
                                            <div class="main_flex_Gap">
                                                <span> In 3 months</span>
                                                <button class="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                <i class="fa-regular fa-star"></i>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td><img src="images/altcoin.webp" width="30" height="30" /></td>
                                        <td>LCAI</td>
                                        <td><span class="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                        <td>Presale</td>
                                        <td>-</td>
                                        <td><span>Hardcap 9000</span></td>
                                        <td> In 3 months</td>
                                        <td>
                                            <div class="main_flex_Gap">
                                                <span> In 3 months</span>
                                                <button class="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                <i class="fa-regular fa-star"></i>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td><img src="images/altcoin.webp" width="30" height="30" /></td>
                                        <td>LCAI</td>
                                        <td><span class="badge rounded-pill bg-warning text-dark">Warning</span></td>
                                        <td>Presale</td>
                                        <td>-</td>
                                        <td><span>Hardcap 9000</span></td>
                                        <td> In 3 months</td>
                                        <td>
                                            <div class="main_flex_Gap">
                                                <span> In 3 months</span>
                                                <button class="btn-main primary-btn small px-4 btn-second_main">Boost</button>
                                                <i class="fa-regular fa-star"></i>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* <!-- faq section --> */}
    <section class="py-4">
        <div class="container">
            <div class="row">
                <div class="col-xl-8">
                    <div class="section-title text-center">
                        <h5 class="fw-bold h4">Frequently Asked Questions</h5>
                        <p>Have questions? We have answers!</p>
                    </div>
                    <div class="accordion-container">
                        <div class="accordion-item">
                            <button class="accordion-header">
                                What are crypto presales? <span class="icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Crypto presales, also known as Initial Coin Offerings (ICOs), token presales, or early-stage token sales, offer investors a chance to purchase a cryptocurrency's tokens before a public launch. These early investment opportunities, often available at a lower price, aim to fund project development and marketing efforts. They are pivotal for both project teams, seeking capital to bring their visions to life, and for investors, looking for potential high returns from the ground floor of innovative blockchain projects.</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-header">
                                How do crypto presales work? <span class="icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Answer to question 2...</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-header">
                                How to find crypto presales?<span class="icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Answer to question 3...</p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <button class="accordion-header">
                                Are crypto presales worth it?<span class="icon">+</span>
                            </button>
                            <div class="accordion-content">
                                <p>Answer to question 3...</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4">
                    <div class="contact_block text-center">
                        <div class="iconbox mb-4">
                            <img src="images/contact-us.png" width="75" height="75"/>
                        </div>
                        <div class="contact_faq">
                            <h5>You have different questions?</h5>
                            <p>Our team will answer all your questions. we ensure a quick response.</p>
                            <a href="" class="btn-main primary-btn shadow">Contact Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* <!--  --> */}
    <section class="listingblock">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-5">
                    <div class="listing_box box_left">
                        <div class="contentview">
                            <h5 class="h3">Your Favorite Coin Missing?</h5>
                            <p>Can't find your coin? List your favorite coin now!
                                Get your community to vote for your coin and gain exposure.</p>
                            <a href="" class="btn-main primary-btn shadow">Submit Coin</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-5">
                    <div class="listing_box ">
                        <div class="contentview">
                            <h5 class="h3">View New Listings</h5><br/>
                            <p>Click the button below to view the New Listings!
                                These coins were just submitted.</p><br/>
                            <a href="" class="btn-main primary-btn shadow">View New Listings</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12 mt-4">
                    <h5 class="h3 text-white mb-3">Find the best new cryptocurrency projects</h5>
                    <p class="text-white">Did ever you wonder where people find the best new cryptocurrency projects, coins and tokens like Doge and Shiba Inu? They use websites like crypto presale. Cryptocurrency projects are listed here before CoinMarketCap, CoinGecko and major exchanges. Find the best crypto moonshots on our website.
                        However: before investing always do your own research (DYOR)! Listing on crypto presale does NOT mean we endorse the project, they could be scams. Be careful with your investments.</p>
                    <h5 class="h3 text-white">How does Crypto Presale work?</h5>
                    <p class="text-white">Did ever you wonder where people find the best new cryptocurrency projects, coins and tokens like Doge and Shiba Inu? They use websites like crypto presale. Cryptocurrency projects are listed here before CoinMarketCap, CoinGecko and major exchanges. Find the best crypto moonshots on our website.
                        However: before investing always do your own research (DYOR)! Listing on crypto presale does NOT mean we endorse the project, they could be scams. Be careful with your investments.</p>
                </div>
            </div>
        </div>
    </section>
    </>
  )
}

export default Listings
