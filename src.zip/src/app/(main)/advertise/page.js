import Services from '@/components/Services';

const Home = () => {
  return <Services />;
};

export default Home;
