import BestPresale from '../../../components/BestPresale'; 
const Home = () => {
  return <BestPresale />;
};

export default Home;
