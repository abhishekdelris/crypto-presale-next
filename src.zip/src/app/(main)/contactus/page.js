import ContactUs from '../../../components/ContactUs'; 
const Home = () => {
  return <ContactUs />;
};

export default Home;
