import Blog from '../../../components/Blog'; 

const Home = () => {
  return <Blog />;
};

export default Home;
