import AllCryptoPresale from '../../../components/AllCryptoPresale';

const Home = () => {
  return <AllCryptoPresale />;
};

export default Home; 