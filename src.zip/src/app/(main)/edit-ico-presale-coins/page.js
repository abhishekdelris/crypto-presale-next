import React from 'react';
import EditListings from '../../../components/EditListings';
import Link from 'next/link';

// This is a Server Component that fetches data
async function fetchICOData() {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/crypto-icos-icoanoucement?type=ongoing`, {
      cache: 'no-store' // Don't cache the response
      // next: { revalidate: 60 } 
    });
  
    if (!response.ok) {
      throw new Error(`Failed to fetch: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error fetching ICO data:", error); 
    return { success: false, data: [], total: 0 }; // Return empty data structure in case of error
  }
}

export default async function EditIcoPresaleCoins() {
  const icoData = await fetchICOData();
  
  return (
    <>
      <section className="brdcrumb">
        <div className="container">
          <ul className="mb-0">
            <li><Link href="/" title="Home">Home</Link></li>
            <li>Edit your Crypto Presale, ICO, IDO, IEO</li> 
          </ul>
        </div> 
      </section>

      {/* Main Content */}
      <div className="container mt-4 mb-5">
        <div className="section-title row mb-4 align-items-center">
          <div className="col-md-8">
            <h2 className="h4 fw-semibold mb-3">Edit ICO/IDO Listings</h2>
            <p className="text-muted">
              At Crypto Presale, take control of your cryptocurrency presale, ICO, IDO, or IEO listings effortlessly. 
              Update and enhance your project's visibility within the vibrant crypto community. 
              Edit your Presale, ICO, IDO, IEO listings now and pave the way for success in the fast-paced realm of digital currencies.
            </p>
          </div>
          <div className="col-md-4 text-md-end mt-3 mt-md-0">
            <Link href="/submit-coin">
              <button className="btn bg-gradient px-4 me-2 mb-2 mb-md-0 text-white">
                <i className="bi bi-plus-circle me-2"></i>Add ICO
              </button>
            </Link>
            <Link href="/">
              <button className="btn bg-gradient btnhover px-4 text-white">
                <i className="bi bi-pencil me-2"></i>Edit Profile
              </button>
            </Link>
          </div>
        </div>
        
        <div className="card shadow-sm border-0">
          <div className="card-body p-4">
            {/* Reusing the EditListings component */}
            <EditListings initialData={icoData} />
          </div>
        </div>
      </div>
      
      {/* FAQ Section */}
      <div className="container mb-5">
        <h3 className="h5 mb-4">Frequently Asked Questions</h3>
        <div className="accordion" id="editICOFaqs">
          <div className="accordion-item">
            <h2 className="accordion-header">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                How do I edit my ICO/IDO listing?
              </button>
            </h2>
            <div id="faq1" className="accordion-collapse collapse" data-bs-parent="#editICOFaqs">
              <div className="accordion-body">
                To edit your ICO/IDO listing, first log in to your account. Then locate your project in the table and click the "Edit" button. This will take you to a form where you can update all relevant information about your project.
              </div>
            </div>
          </div>
          
          <div className="accordion-item">
            <h2 className="accordion-header">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                How long does it take for my changes to appear?
              </button>
            </h2>
            <div id="faq2" className="accordion-collapse collapse" data-bs-parent="#editICOFaqs">
              <div className="accordion-body">
                Most changes are reflected immediately after submission. However, some changes may require review by our team and could take up to 24 hours to appear on the platform.
              </div>
            </div>
          </div>
          
          <div className="accordion-item">
            <h2 className="accordion-header">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                Can I change my ICO/IDO launch date?
              </button>
            </h2>
            <div id="faq3" className="accordion-collapse collapse" data-bs-parent="#editICOFaqs">
              <div className="accordion-body">
                Yes, you can update your project's start and end dates. Please ensure that changes are made at least 48 hours before the previously announced date to maintain credibility with potential investors.
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}