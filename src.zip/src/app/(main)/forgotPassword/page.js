
import ForgotPass from '../../../components/ForgotPass'; 

const forgotPassword = () => {
  return <ForgotPass />;
};

export default forgotPassword;
