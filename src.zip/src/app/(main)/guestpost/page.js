import GuestPost from '../../../components/GuestPost'; 

const Home = () => {
  return <GuestPost />;
};

export default Home;
 