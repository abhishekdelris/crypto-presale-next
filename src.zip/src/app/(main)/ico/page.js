import ICOPage from '../../../components/ICO';

const Home = () => {
  return <ICOPage />;
};

export default Home; 