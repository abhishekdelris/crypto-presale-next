import IDOPage from '../../../components/IDO';

const Home = () => {
  return <IDOPage />;
};

export default Home;  