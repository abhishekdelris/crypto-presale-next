import IEOPage from '../../../components/IEO';
const Home = () => {
  return <IEOPage />;
};

export default Home; 