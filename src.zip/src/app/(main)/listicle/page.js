
import Listicle from '@/components/Listicle';

const Home = () => {
  return <Listicle />;
};

export default Home;
