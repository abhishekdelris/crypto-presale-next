
import Listings from '../../../components/Listings';

const Listing = () => {
  return <Listings />;
};

export default Listing;
