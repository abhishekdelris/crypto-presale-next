import Login from '../../../components/Login'; 

const Home = () => {
  return <Login />;
};

export default Home;
