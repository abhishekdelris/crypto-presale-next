import ProjectReview from '../../../components/ProjectReview';

const Home = () => {
  return <ProjectReview />;
};

export default Home;