import React from 'react';
import Signup from '../../../components/Signup'; 

const Home = () => {
  return <Signup />;
};

export default Home;

