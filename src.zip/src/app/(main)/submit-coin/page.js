import SubmitCoin from '../../../components/SubmitCoin'; 

const Home = () => {
  return <SubmitCoin />;
};

export default Home;

