import TrendingPresale from '../../../components/TrendingPresale'; 
const Home = () => {
  return <TrendingPresale />;
};

export default Home;
