
import UpdateListing from '../../../../components/UpdateListing'; 

const Home = () => {
 
  return <UpdateListing />;
};

export default Home;
 