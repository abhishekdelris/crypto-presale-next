"use client";
import { Provider } from "react-redux";
import "./globals.scss";
import store from "../../../shared/redux/store";
import { AdminAuthProvider } from "../../hooks/admin_authContext";
import AdminSessionprovidersWrappers from '@/hooks/providers/AdminSessionprovidersWrappers';

const RootLayout = ({ children }) => {
  return (
    <AdminSessionprovidersWrappers>
    <AdminAuthProvider>
      <Provider store={store}>
        {children} 
      </Provider>
    </AdminAuthProvider>
    </AdminSessionprovidersWrappers>
  );
};
export default RootLayout;
