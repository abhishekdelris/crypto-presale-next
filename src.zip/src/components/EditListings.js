"use client";

import React, { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import altcoinImage from "../images/altcoin.webp";
import { useRouter } from "next/navigation";
import { useUserAuth } from "../hooks/authContext";
import Link from "next/link";
import axios from 'axios';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import LoginModal from "./LoginModal";
import SearchableDropdown from "./SearchableDropdown";


// Constants
const NEXT_PUBLIC_API_URL = process.env.NEXT_PUBLIC_NEXT_PUBLIC_API_URL || '';
const DEFAULT_PAGE_SIZE = 15;


export default function EditListings({ initialData }) {
  const router = useRouter();
  const { isAuthenticated, user } = useUserAuth();
  
  // Filter states
  const [filters, setFilters] = useState({
    type: "ongoing",
    launchpad: 0,
    searchQuery: "",
    tempSearchQuery: "",
    dateRange: [null, null]
  });
  
  // Data states
  const [icoData, setIcoData] = useState(initialData?.data || []);
  const [totalCount, setTotalCount] = useState(initialData?.total || 0);
  const [pagination, setPagination] = useState({
    skip: 0,
    limit: DEFAULT_PAGE_SIZE,
    hasMore: true
  });
  
  // UI states
  const [isLoading, setIsLoading] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [pendingLikeAction, setPendingLikeAction] = useState(null);
  const [userLikes, setUserLikes] = useState({});
  const [launchpads, setLaunchpads] = useState([]);

  // Extract values from state objects for readability
  const { type, launchpad, searchQuery, tempSearchQuery, dateRange } = filters;
  const [startDate, endDate] = dateRange;
  const { skip, limit, hasMore } = pagination;

  // Modal handlers
  const handleOpenLoginModal = () => setShowLoginModal(true);
  const handleCloseLoginModal = () => setShowLoginModal(false);


  const formatToYYYYMMDD = (inputDate) => {
    const date = new Date(inputDate);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are 0-based
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };
  const getTimeAgo = (timestamp) => {
    if (!timestamp) return "Unknown time";
   const formate =  formatToYYYYMMDD(timestamp)
    const created = new Date(formate);
    const now = new Date();
  
    if (isNaN(created)) return "Invalid date";
  
    const diffInMs = created - now;
    const isFuture = diffInMs > 0;
  
    const absMinutes = Math.floor(Math.abs(diffInMs) / (1000 * 60));
    const absHours = Math.floor(absMinutes / 60);
    const absDays = Math.floor(absMinutes / (60 * 24));
    const absWeeks = Math.floor(absDays / 7);
    const absMonths = Math.floor(absDays / 30); // Approximation
  
    // const suffix = isFuture ? "from now" : "ago";
  
    if (absMinutes < 60) {
      return `${absMinutes} minute${absMinutes !== 1 ? "s" : ""} `;
    } else if (absHours < 24) {
      return `${absHours} hour${absHours !== 1 ? "s" : ""} `;
    } else if (absDays < 7) {
      return `${absDays} day${absDays !== 1 ? "s" : ""} `;
    } else if (absWeeks < 4) {
      return `${absWeeks} week${absWeeks !== 1 ? "s" : ""} `;
    } else {
      return `${absMonths} month${absMonths !== 1 ? "s" : ""} `;
    }
  };
  function formatNumber(num) {
    if (!num) return "N/A";
    if (num >= 1e9) {
      return (num / 1e9).toFixed(2).replace(/\.00$/, "") + "B";
    } else if (num >= 1e6) {
      return (num / 1e6).toFixed(2).replace(/\.00$/, "") + "M";
    } else if (num >= 1e3) {
      return (num / 1e3).toFixed(2).replace(/\.00$/, "") + "K";
    }
    return num.toString();
  }

  // Handle successful login
  const handleLoginSuccess = useCallback((userData) => {
    router.reload();
    if (pendingLikeAction) { 
      handleLike(pendingLikeAction.ico_id, pendingLikeAction.pre_like);
      setPendingLikeAction(null);
    }
  }, [pendingLikeAction, router]);

  // Filter change handlers
  const handleTypeChange = (event) => {
    setFilters(prev => ({ ...prev, type: event.target.value }));
    resetPagination();
  };

  const handleLaunchpadChange = (selected) => {
    setFilters(prev => ({ ...prev, launchpad: Number(selected.value) }));
    resetPagination();
  };

  const handleSearchInputChange = (event) => {
    setFilters(prev => ({ ...prev, tempSearchQuery: event.target.value }));
  };

  const handleSearch = () => {
    setFilters(prev => ({ ...prev, searchQuery: prev.tempSearchQuery }));
    resetPagination();
  };

  const handleDateRangeChange = (update) => {
    setFilters(prev => ({ ...prev, dateRange: update }));
    if (update[0] !== null && update[1] !== null) {
      resetPagination();
    }
  };

  // Pagination handlers
  const resetPagination = () => {
    setPagination(prev => ({
      ...prev,
      skip: 0,
      hasMore: true
    }));
  };

  const handleLoadMore = () => {
    setPagination(prev => ({
      ...prev,
      skip: prev.skip + prev.limit
    }));
  };

  // Like/Upvote handler
  const handleLike = async (ico_id, pre_like) => {
    if (!isAuthenticated) { 
      setPendingLikeAction({ ico_id, pre_like });
      handleOpenLoginModal();
      return;
    }

    try {
      const res = await fetch(`/api/like_counts`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ico_id,
          user_id: user.id,
          pre_like
        })
      });

      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.message || 'Failed to like ICO');
      }

      if (data.success) {
        // Update like status
        setUserLikes(prev => ({
          ...prev,
          [ico_id]: true
        }));
        
        // Update count in the UI
        setIcoData(prev => {
          const updatedData = [...prev];
          const icoIndex = updatedData.findIndex(ico => ico.id === ico_id);
          if (icoIndex !== -1) {
            updatedData[icoIndex].likes_counts = data.new_count || (pre_like + 1);
          }
          return updatedData;
        });
      }
    } catch (error) {
      console.error("Error liking ICO:", error);
      // Show user-friendly error - in a real app you'd use a toast notification
      alert("Failed to like. Please try again.");
    }
  };

  // Fetch user likes
  useEffect(() => {
    const fetchUserLikes = async () => {
      if (!isAuthenticated || !user) return;
      
      try {
        const res = await fetch(`/api/user_likes?user_id=${user.id}`);
        const data = await res.json();
        
        if (!res.ok) {
          throw new Error(data.message || 'Failed to fetch user likes');
        }
        
        if (data.success) {
          // Convert array to object for O(1) lookups
          const likesObj = {};
          data.likes.forEach(like => {
            likesObj[like.ico_id] = true;
          });
          setUserLikes(likesObj);
        }
      } catch (error) {
        console.error("Error fetching user likes:", error);
      }
    };
    
    fetchUserLikes();
  }, [isAuthenticated, user]);

  // Fetch launchpads
  useEffect(() => {
    const fetchLaunchpads = async () => {
      try {
        const response = await axios.get(`/api/admin/launchpad`);
        
        if (!response.data.success) {
          throw new Error(response.data.message || 'Failed to fetch launchpads');
        }
        
        const result = response.data.data || [];
        const sortedData = result.sort((a, b) => a.title.localeCompare(b.title));
        setLaunchpads(sortedData);
      } catch (err) {
        console.error('Error fetching launchpad data:', err);
      }
    };
    
    fetchLaunchpads();
  }, []);

  // Main data fetching function
  const fetchData = useCallback(async () => {
    setIsLoading(true);
    
    try {
      // Build query parameters
      const params = new URLSearchParams();
     
      params.append('skip', skip.toString());
      params.append('limit', limit.toString());
      
      if (searchQuery) {
        params.append('search', searchQuery);
      }
      
      if (type) {
        params.append('type', type);
      }
      
      if (launchpad !== 0) {
        params.append('launchpad', launchpad.toString());
      }
      
      if (startDate && endDate) {
        params.append('start_date', startDate.toISOString().split('T')[0]);
        params.append('end_date', endDate.toISOString().split('T')[0]);
      }

      const response = await fetch(`/api/crypto-icos-icoanoucement?${params.toString()}`);
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const result = await response.json();
      
      if (result.success) {
        // For initial load or filter reset, replace data
        // For "load more", append data
        if (skip === 0) {
          setIcoData(result.data);
        } else {
          setIcoData(prev => [...prev, ...result.data]);
        }
        
        setTotalCount(result.total);
        
        // Check if we've loaded all the data
        setPagination(prev => ({
          ...prev,
          hasMore: skip + limit < result.total
        }));
      } else {
        throw new Error(result.message || "Failed to fetch data");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      // In a real app, show a toast notification here
    } finally {
      setIsLoading(false);
    } 
  }, [skip, limit, searchQuery, type, launchpad, startDate, endDate]);

  // Effect to fetch data when filters or pagination changes
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Prepare launchpad options for dropdown
  const launchpadOptions = [
    { value: 0, label: "All Launchpads" },
    ...launchpads.map(launchpad => ({
      value: launchpad.id,
      label: launchpad.title
    }))
  ];

  // Get current launchpad name for display
  const currentLaunchpadName = 
    launchpad !== 0 ? 
    launchpadOptions.find(o => o.value === launchpad)?.label : 
    '';

  return (
    <>
      {/* Search and Filter Bar */}
      <div className="row mb-4">
        <div className="col-md-3">
          <input
            type="text"
            className="form-control"
            placeholder="Search By Keyword..."
            value={tempSearchQuery}
            onChange={handleSearchInputChange}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
        </div>
        
        <div className="col-md-3"> 
          <SearchableDropdown
            options={launchpadOptions}
            placeholder="Select Launchpad"
            handleData={handleLaunchpadChange}
          />
        </div>
        
        <div className="col-md-2">
          <select
            value={type}
            onChange={handleTypeChange}
            className="form-select"
          >
            <option value="">Select Type</option>
            <option value="ongoing">Ongoing</option>
            <option value="upcoming">Upcoming</option>
            <option value="ended">Ended</option>
          </select>
        </div>
        
        <div className="col-md-3">
          <DatePicker
            selectsRange={true}
            startDate={startDate}
            endDate={endDate}
            className="form-select"
            onChange={handleDateRangeChange}
            isClearable={true}
            placeholderText="Select Date Range"
          />
        </div>
        
        <div className="col-md-1">
          <button 
            className="btn bg-gradient text-light w-100" 
            onClick={handleSearch}
          >
            <i className="bi bi-search" />
          </button>
        </div>
      </div>

      {/* Results Summary */}
      <div className="mb-3">
        <p>
          Showing {icoData.length} of {totalCount} results
          {launchpad !== 0 && ` for ${currentLaunchpadName}`}
          {searchQuery && ` matching "${searchQuery}"`}
        </p>
      </div>

      {/* ICO Table */}
      <div className="table-responsive">
        <table className="table table-hover"> 
          <thead className="table-light">
            <tr>
              <th>Name</th>
              <th>Stage</th>
              <th>Launchpad</th>
              <th>Upvotes</th>
              <th>End In</th>
              <th>Tokens for Sale</th>
              <th>Rate</th>
              <th>Fundraising Goal</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {icoData.length > 0 ? (
              icoData.map((ico, index) => (
                <tr key={ico.id || index}>
                  <td>
                    <div className="d-flex align-items-center">
                      <Image
                        src={
                          ico.image
                            ? ico.image.startsWith("https://d3iuzwoiyg9qa8.cloudfront.net/")
                              ? ico.image 
                              : `https://d3iuzwoiyg9qa8.cloudfront.net/webadmin/storage/${ico.image}`
                            : altcoinImage
                        }
                        alt={ico.img_alt_title || "ICO Project"}
                        width={32}
                        height={32}
                        className="project-icon me-2"
                      />
                      <div className="set_ico_name">
                        <Link href={`/crypto-ico-details/${ico.slug}`} className="text_customization">
                          {ico.name || "Unnamed Project"}
                        </Link>
                        <label className="set_alias">
                          {ico.alias ? `(${ico.alias})` : ""}
                        </label>
                      </div>
                      {ico.featured === 1 && <span className="featured-tag ms-2">Featured</span>}
                    </div>
                  </td>
                  <td>{ico.ico_ido_type === 3 ? "Presale" : "Presale"}</td>
                  <td>
                    {launchpadOptions.find(option => option.value === ico.launchpad)?.label || 'On Website'}
                  </td>
                  <td>
                    <button
                      className={`upvote-btn ${userLikes[ico.id] ? 'liked' : ''}`}
                      onClick={() => handleLike(ico.id, ico.likes_counts || 0)}
                    >
                      <i className={`bi ${userLikes[ico.id] ? 'bi-hand-thumbs-up-fill text-primary' : 'bi-hand-thumbs-up'}`} />{" "}
                      {ico.likes_counts || 0}
                    </button>
                  </td>
                  <td>
                    <span
                      data-bs-toggle="tooltip"
                      data-bs-placement="top"
                      title={`Start from ${formatToYYYYMMDD(ico.start_time)} to ${formatToYYYYMMDD(ico.end_time)}`}
                      className="custom-tooltip"
                    >
                      {getTimeAgo(ico.end_time)}
                    </span>
                  </td>
                  <td>{formatNumber(ico.fund_asking_for)}</td>
                  <td>
                    {ico.ico_price
                      ? `${ico.ico_price} (${ico.accept_type || "USDT"})`
                      : "N/A"}
                  </td>
                  <td>
                    {ico.fund_asking_for
                      ? `${formatNumber(ico.fund_asking_for)} (${ico.accept_type || "USDT"})`
                      : "N/A"}
                  </td>
                  <td>
                    <div>
                      {isAuthenticated ? (
                        <Link href={`/update-request/${ico.slug}`}>
                          <button className='btn btn-outline-warning'>Edit</button>
                        </Link>
                      ) : (
                        <button 
                          className='btn btn-outline-warning' 
                          onClick={handleOpenLoginModal}
                        >
                          Edit
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="9" className="text-center py-4">
                  {isLoading ? (
                    <div className="spinner-border text-primary" role="status">
                      <span className="visually-hidden">Loading...</span>
                    </div>
                  ) : (
                    "No IDO data available"
                  )}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {/* Loading Indicator */}
      {isLoading && icoData.length > 0 && (
        <div className="text-center py-4">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      )}
      
      {/* Load More Button */}
      {hasMore && !isLoading && (
        <div className="text-center mt-4 mb-5">
          <button className="btn bg-gradient px-4 text-light" onClick={handleLoadMore}>   
            Load More
          </button>
        </div>
      )}
      
      {/* Login Modal */}
      {showLoginModal && (
        <LoginModal 
          show={showLoginModal} 
          handleClose={handleCloseLoginModal}
          onLoginSuccess={handleLoginSuccess}
        />
      )}
    </>
  );
}