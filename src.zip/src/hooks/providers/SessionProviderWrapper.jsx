// src/components/providers/SessionProviderWrapper.jsx
// "use client";

// import { SessionProvider } from "next-auth/react";

// export default function SessionProviderWrapper({ children }) {
//   return (
//     <SessionProvider basePath="/api/auth">
//       {children}
//     </SessionProvider>
//   );
// }


"use client";

import { SessionProvider } from "next-auth/react";

export default function SessionProviderWrapper({ children }) {
  return (
    <SessionProvider session={null} basePath="/api/auth">
      {children}
    </SessionProvider>
  );
}